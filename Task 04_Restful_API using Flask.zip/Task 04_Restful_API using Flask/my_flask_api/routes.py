def create_routes(app):
    @app.route('/', methods=['GET'])
    def index():
        return "Hello, World!"

    @app.route('/user/<int:id>', methods=['GET'])
    def get_user(id):
        from models import User  # Import inside the function to avoid circular imports
        from schemas import user_schema  # Import inside the function to avoid circular imports
        user = User.query.get_or_404(id)
        return user_schema.jsonify(user)

    @app.route('/users', methods=['GET'])
    def get_users():
        from models import User  # Import inside the function to avoid circular imports
        from schemas import users_schema  # Import inside the function to avoid circular imports
        users = User.query.all()
        return users_schema.jsonify(users)
