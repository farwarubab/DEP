from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your_database.db'

db = SQLAlchemy(app)
ma = Marshmallow(app)

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your_database.db'
    db.init_app(app)
    ma.init_app(app)

    # Import and register routes inside the function to avoid circular imports
    from routes import create_routes
    create_routes(app)

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
